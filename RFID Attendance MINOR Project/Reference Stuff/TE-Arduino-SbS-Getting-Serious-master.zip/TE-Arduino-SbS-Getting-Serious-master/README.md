# TE-Arduino-SbS-Getting-Serious

This is the code repository for Tech Explorations Arduino Step by Step Getting Serious. 

The course home page is at txplore.tv/courses/arduino-step-by-step-getting-serious

By taking this course, you will extend your knowledge of Arduino components and techniques and build up new skills in the largest, and the most comprehensive course on the Web!
